/* Site specific definitions */

#ifndef SITE_DEF_H
#define SITE_DEF_H
/* #define BIT_SLICER_LOG 1 */
/* #define CACHE_DEBUG 1 */
/* #define CACHE_STATUS 1 */
/* #define DVB_DEMUX_LOG 1 */
/* #define DVB_MUX_LOG 1 */
/* #define RAW_DECODER_LOG 1 */
/* #define RAW_DECODER_PATTERN_DUMP 1 */
#endif /* SITE_DEF_H */
